<?php echo Form::open(['url' => '/in_shopping_carts/'.$product->pivot->id, 'method' => 'DELETE', 'class' => 'inline-block']); ?>

  <input type="submit" name="" value="Eliminar" class="btn btn-link red-text no-padding no-margin no-transform">
<?php echo Form::close(); ?>

