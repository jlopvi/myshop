<?php echo Form::open(['url' => 'in_shopping_carts', 'method' => 'POST', 'class' => 'inline-block']); ?>

  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
  <input type="submit" class="btn btn-info" value="Agregar al Carrito <?php echo e($product->pricing); ?>">
<?php echo Form::close(); ?>

