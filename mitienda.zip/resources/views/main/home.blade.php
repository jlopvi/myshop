@extends('layouts.app')

@section('title', 'Bienvenidos a Mi tienda')

@section('content')
  <h1>Bien venido a mi tienda</h1>
@endsection
